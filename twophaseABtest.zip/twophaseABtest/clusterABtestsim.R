# clusterABtestsim.R
# Simulate live data from an A/B test with covariates
# where users belong to a social network with clusters.
# Compare naive A/B testing with the proposed methodology.

rm(list = ls()) # clear the environment

# set working directory to location of source code file
setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest")

# load source files
source("two_phase_ABtest_source.R")

# load relevant libraries
library(igraph) # for graph clustering
library(dplyr) # for easy data frame manipulation and summaries
library(lme4) # for glmer
library(foreach)
library(doParallel)

# set random seed
set.seed(123)

n.cores = 10 # for parallel processing to speed up randomization test

############# Simulation Parameters #############################
n_sim = 100 # number of times the A/B tests are repeated
N = 1000 # number of candidates, i.e., total number of vertices in the network
n = 200 # sample size
p = 3 # number of covariates (not including the intercept)
n_clust = 20 # number of clusters in the social network (5, 10, 20)
tau = 0 # treatment effect
beta = 1:(p+1)*c(-1,1) # fixed regression coefficients for covariates. 
within_cluster_prob = 0.9
between_cluster_prob = 1-within_cluster_prob
response_mechanism = "logistic"  # one of "logistic" (a), "probit" (b), "threshold" (c)
sigma2_clusters = 25 # variance of random cluster effects.
delta_fixed = 10 # fixed exposure effect for network interference
#########################################################################

# Generate the graph
cluster_assignments = as.numeric(cut(1:N,n_clust))
adjacency_matrix = matrix(0, nrow = N, ncol = N)
for(i in 1:(N-1)){
  cluster_i = cluster_assignments[i]
  for(j in (i+1):N){
    cluster_j = cluster_assignments[j]
    if(cluster_i == cluster_j){
      adjacency_matrix[i,j] = rbinom(1,size = 1, prob = within_cluster_prob)
    }
    else{
      adjacency_matrix[i,j] = rbinom(1, size = 1, prob = between_cluster_prob)
    }
    adjacency_matrix[j,i] = adjacency_matrix[i,j] # make it symmetric
  }
}

# Generate the covariates
X_all = matrix(rnorm(N*p, mean = c(-1,1)*(1:p)/p, sd = 0.2), nrow = N, ncol = p)
X_all = cbind(1,X_all) # now add a column of ones for the intercept


# Generate random effects if needed
gammas = rnorm(n_clust, mean = 0, sd = sqrt(sigma2_clusters))
# generate random effects for each individual based on cluster assignment
gamma_all = numeric(N)
for(i in 1:N){
  gamma_all[i] = gammas[cluster_assignments[i]]
}


naive_AB_pvals = numeric(n_sim)
rand_pvals = numeric(n_sim) # two-phase randomization p-values
wald_pvals = numeric(n_sim) # two-phase wald p-values


# pre-testing: cluster the graph
graph1 = graph_from_adjacency_matrix(adjacency_matrix, mode = "undirected") # create an igraph object
estimated_clusters = cluster_louvain(graph= graph1)$memberships

for(iter in 1:n_sim){
  print(paste("Beginning A/B Test Simulation ", iter, sep = ""))
  naive_AB_out = naive_AB_test_sim(n = n, X_all = X_all, tau = tau, beta = beta, gamma_all = gamma_all, delta_fixed = delta_fixed,
                                   adjmat = adjacency_matrix, response_mechanism = response_mechanism,
                                   estimated_clusters = estimated_clusters)
  naive_AB_pvals[iter] = naive_AB_out$p.value
  two_phase_sample_found = FALSE
  while(!two_phase_sample_found){
    tryCatch({
      two_phase_out = two_phase_ABtest_sim_randomization(n1 = n/2, n2 = n/2, estimated_clusters = estimated_clusters, X_all = X_all,
                                              tau = tau, beta = beta, gamma_all = gamma_all, delta_fixed = delta_fixed,
                                              adjmat = adjacency_matrix, response_mechanism = response_mechanism,
                                              B = 1000, n.cores = n.cores)
      rand_pvals[iter] = two_phase_out$randomization.p.value
      print(paste("Two Phase Rand p-value: ", rand_pvals[iter], sep = ""))
      wald_pvals[iter] = two_phase_out$wald.p.value
      print(paste("Two Phase Wald p-value: ", wald_pvals[iter], sep = ""))
      two_phase_sample_found = TRUE
      
      
    }, error = function(e){
      print(paste("Error:", e$message, "Retrying", sep = " "))
    })
    
  }
  
}

results_df = cbind(naive_AB_pvals, rand_pvals, wald_pvals)
colnames(results_df) = c("Naive pvals","Rand pvals", "Wald pvals")
namestr = paste("rand_ABtesttau",tau,"p",p,"pwithin",within_cluster_prob,"k",n_clust,
                response_mechanism,".csv",sep="")

# Uncomment these lines to save the results:
# setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest/SimResults")
# write.csv(results_df, namestr)

# estimate the power (if tau = 0 this is type I error)
mean(naive_AB_pvals <= 0.05)
mean(rand_pvals <= 0.05)
mean(wald_pvals <= 0.05)

# clear the environment
rm(list = ls())

# load libraries
library(igraph)
library(lme4)
library(R.matlab) # used to read in the demographic information (covariates)
library(dplyr)
library(foreach)
library(doParallel)

# set the working directory
setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest")
# change to location of twophaseABtest folder

# source code
source("two_phase_ABtest_source.R")

# read in the edge list
caltech36 = read.table("caltech36.txt",header = FALSE)
caltech36_edgelist = as.matrix(caltech36, ncol = 2)

# read in node information
Caltech36_tmp <- readMat("Caltech36.mat")
covariate_data = Caltech36_tmp$local.info
# the covariates are all categorical except for year
# values of 0 are MISSING
covariate_data[covariate_data == 0] <- NA

colnames(covariate_data) = c("Faculty/Student Status", "Gender", "Major",
                             "Second Major/Minor (if applicable)",
                             "Dormitory/House",
                             "Year",
                             "High School")
covariates_df = as.data.frame(covariate_data)

# Faculty/Student status has 4 levels: 1,2,5,6. 1 represents students, 2 faculty, and 5/6 are used
# for more specialized roles (e.g. grad students, postodcs). To make this easier, we will turn this
# into a binary variable for students.
covariates_df$`Faculty/Student Status` = ifelse(covariates_df$`Faculty/Student Status` == 1, 1, 0)
covariates_df$Gender = as.factor(covariates_df$Gender)
covariates_df$Major = as.factor(covariates_df$Major)
covariates_df$`Dormitory/House` = as.factor(covariates_df$`Dormitory/House`)

mean(is.na(covariates_df$`Second Major/Minor (if applicable)`))
# we will drop:
# 1) second major: most are NA
# 2) High School and Major: too many levels. Very few students actually share the same high school in the caltech dataset.
covariates_df = covariates_df[,-c(3,4,7)]

# standardize the year
covariates_df$Year = scale(covariates_df$Year)

# # make the X matrix (model matrix)
# ytmp = rnorm(nrow(covariates_df))
# X_all = model.matrix(ytmp ~ ., data = covariates_df, na.action = na.pass) # this automatically drops rows with NA

# only keep complete cases
keep_rows = which(complete.cases(covariates_df))
remove_rows = setdiff(1:nrow(covariates_df),keep_rows)
complete_covariates_df = covariates_df[keep_rows,]

# create the network
G = graph_from_edgelist(caltech36_edgelist, directed = FALSE)
# remove users without complete covariate information
Gtmp = delete_vertices(G, remove_rows)
set.seed(123)
cl_output_tmp = cluster_louvain(Gtmp, resolution = 0.7) 
estimated_clusters_tmp = membership(cl_output_tmp)
table(estimated_clusters_tmp)
# 5 of the 4 clusters have 1 or 2 members, remove these
little_to_no_friends = which(estimated_clusters_tmp >= 5)
G_final = delete_vertices(Gtmp, little_to_no_friends)
cl_output = cluster_louvain(G_final, resolution = 0.7)
estimated_clusters = membership(cl_output)
table(estimated_clusters)

# make the X matrix
complete_covariates_df = complete_covariates_df[-little_to_no_friends,]
ytmp = rnorm(nrow(complete_covariates_df))
X_all = model.matrix(ytmp ~ ., data = complete_covariates_df)

# Plot graph with clusters
palette <- rainbow(length(table(estimated_clusters)))
V(G_final)$color <- palette[estimated_clusters]
# l1 = layout_with_fr(G, area=length(V(G))^2 * 0.01)
l1 = layout_with_fr(G_final)
plot(G_final, vertex.size =3, vertex.label = "", layout = l1)
legend("topleft", legend = paste("Cluster ",levels(as.factor(estimated_clusters))),
       col = palette, pt.cex = 1, pch = 16, cex = 0.8,
       bty = "n", inset = c(0.15,0.05))

adjacency_matrix = as_adjacency_matrix(G_final)

############# Simulation Parameters #############################
n_sim = 200 # number of times the A/B tests are repeated
N = length(V(G_final)) # number of candidates, i.e., total number of vertices in the network
n = 300 # sample size
p = ncol(X_all)-1 # number of covariates (not including the intercept)
tau = 2 # treatment effect (0, 0.5, 1, 1.5, 2)
response_mechanism = "probit"  # one of "logistic" (a), "probit" (b), "threshold" (c)
if(response_mechanism == "threshold"){
  beta = 2*(1:(p+1)*c(-1,1)/(p+1)) # fixed regression coefficients for covariates. 
} else{
  beta = 1:(p+1)*c(-1,1)/(p+1)
}
sigma2_clusters = 25 # variance of random cluster effects.
delta_fixed = 4 # fixed exposure effect for network interference
n.cores = 10
exposure_threshold = 0.2 # exposure threshold used when response_mechanism = "threshold"
#########################################################################

set.seed(123)

colnames(X_all) = NULL

# Generate random effects if needed
n_clust = length(table(estimated_clusters))
gammas = rnorm(n_clust, mean = 0, sd = sqrt(sigma2_clusters))
# generate random effects for each individual based on cluster assignment
gamma_all = numeric(N)
for(i in 1:N){
  gamma_all[i] = gammas[estimated_clusters[i]]
}


naive_AB_pvals = numeric(n_sim)
rand_pvals = numeric(n_sim) # two-phase randomization p-values
wald_pvals = numeric(n_sim) # two-phase wald p-values


for(iter in 1:n_sim){
  print(paste("Beginning A/B Test Simulation ", iter, sep = ""))
  naive_AB_out = naive_AB_test_sim(n = n, X_all = X_all, tau = tau, beta = beta, gamma_all = gamma_all, delta_fixed = delta_fixed,
                                   adjmat = adjacency_matrix, response_mechanism = response_mechanism,
                                   estimated_clusters = estimated_clusters, exposure_threshold = exposure_threshold)
  naive_AB_pvals[iter] = naive_AB_out$p.value
  print(paste("Naive p-value: ", naive_AB_pvals[iter], sep = ""))
  two_phase_sample_found = FALSE
  while(!two_phase_sample_found){
    tryCatch({
      two_phase_out = two_phase_ABtest_sim_randomization(n1 = n/2, n2 = n/2, estimated_clusters = estimated_clusters, X_all = X_all,
                                                         tau = tau, beta = beta, gamma_all = gamma_all, delta_fixed = delta_fixed,
                                                         adjmat = adjacency_matrix, response_mechanism = response_mechanism,
                                                         B = 1000, n.cores = n.cores, exposure_threshold = exposure_threshold)
      rand_pvals[iter] = two_phase_out$randomization.p.value
      print(paste("Two Phase Rand p-value: ", rand_pvals[iter], sep = ""))
      wald_pvals[iter] = two_phase_out$wald.p.value
      print(paste("Two Phase Wald p-value: ", wald_pvals[iter], sep = ""))
      two_phase_sample_found = TRUE
      
      
    }, error = function(e){
      print(paste("Error:", e$message, "Retrying", sep = " "))
    })
    
  }
  
}

results_df = cbind(naive_AB_pvals, rand_pvals, wald_pvals)
colnames(results_df) = c("Naive pvals","Rand pvals", "Wald pvals")
namestr = paste("caltech36n",n,"tau",tau,response_mechanism,".csv",sep="")

# Uncomment these lines to save the results:
# setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest/SimResults")
# write.csv(results_df, namestr)

# estimate the power (if tau = 0 this is type I error)
mean(naive_AB_pvals <= 0.05)
mean(rand_pvals <= 0.05)
mean(wald_pvals <= 0.05)


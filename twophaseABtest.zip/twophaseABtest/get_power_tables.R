rm(list = ls())

library(kableExtra)

# change directory to location of "SimResults" folder
setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest/SimResults")

# response_mechanism = "logistic" # logistic (a), probit (b), or threshold (c)
tau = 0 # 0 or 2
run_grid = as.data.frame(expand.grid(n = c(200,300),n_clust = c(5,10,20),
                                     within_cluster_prob = c(0.9,0.8),
                                     p = c(3,6)))


full_power_table = NULL

for(response_mechanism in c("logistic","probit","threshold")){
  power_table = matrix(NA, nrow = nrow(run_grid), ncol = 3)
  for(iter in 1:nrow(run_grid)){
    n = run_grid$n[iter]
    p = run_grid$p[iter]
    n_clust = run_grid$n_clust[iter]
    within_cluster_prob = run_grid$within_cluster_prob[iter]
    namestr = paste("rand_ABtestn",n,"tau",tau,"p",p,"pwithin",within_cluster_prob,"k",n_clust,
                    response_mechanism,".csv",sep="")
    tmpdata = read.csv(namestr)[,-1]
    power_table[iter,] = apply(tmpdata, 2, function(x) mean(x <= 0.05)  )
  }
  colnames(power_table) = c("naive", "rand", "Wald")
  full_power_table = cbind(full_power_table, power_table)
  
}

full_power_table





full_power_table2 = round(full_power_table, 2)

run_grid_reformatted = data.frame(p = run_grid$p, pw = run_grid$within_cluster_prob,
                                  K = run_grid$n_clust, n = run_grid$n )
full_power_table2 = cbind(run_grid_reformatted, full_power_table2)
# full_power_table2 = rbind(Scenario,full_power_table2)
colnames(full_power_table2) = c(colnames(run_grid_reformatted),paste(c("Naive","Rand","Wald"),c(rep("(a)",3),rep("(b)",3),rep("(c)",3))) )

kable(full_power_table2, format = "latex",digits = c(0,1,0,0,rep(2,9)))

# caltechpowercurves.R

rm(list = ls())

# set the working directory to the "SimResults" subfolder
setwd("C:/Users/riosn/OneDrive/Desktop/twophaseABtest/SimResults")

tau_vec = c(0,0.5,1,1.5)
n_vec = c(200,300)
response_mechanisms = c("logistic","probit","threshold")

par(mfrow = c(2,3))
par(mar = c(4,4,1.5,0.5))

first_pic = TRUE
for(n in n_vec){
  
  for(response_mechanism in response_mechanisms){
    power_mat = matrix(NA, nrow = length(tau_vec), ncol = 3)
    for(i in 1:length(tau_vec)){
      namestr = paste("caltech36n",n,"tau",tau_vec[i],response_mechanism,".csv",sep="")
      tmp_data = read.csv(namestr)[,-1]
      power_mat[i,] = apply(tmp_data, 2, function(x) mean(x <= 0.05)  )
      
    }
    if (response_mechanism == "logistic"){
      ylabel = "Power"
      scen_label = "(a)"
    } else{
      ylabel = ""
      if(response_mechanism == "probit"){
        scen_label = "(b)"
      } else{
        scen_label = "(c)"
      }
    }
    if(n == 200){
      xlabel = ""
    } else{
      xlabel = "Treatment Effect"
      # par(mar = c(2.5,2.5,0,0.5))
    }
    
    mainstr = paste("Scenario", scen_label,"n=",n, sep = " ")
    matplot(tau_vec,power_mat, type = "l", col = c("black","blue","red"),
            lty = 1, lwd = 2,ylim = c(0,1), main = mainstr,
            xlab = xlabel, ylab = ylabel)
    if(first_pic == TRUE){
      legend("topleft", legend = c("Naive","Randomization","Wald"),lty = 1, lwd = 2,
             col = c("black","blue","red"))
    }
    first_pic = FALSE
  }
  
  
  
}


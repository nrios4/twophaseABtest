# two_phase_ABtest_source.R

#####################################################
# helper function for simulation
generate_next_response <- function(treatments, X_sample, tau, beta, gamma_sample, response_mechanism, delta_fixed, adjmat_sample, i,
                                   exposure_threshold = 0.5){
  
  treatment = treatments[i]
  xi = X_sample[i,]
  
  if(response_mechanism == "logistic" || response_mechanism == "probit"){
    gamma_i = gamma_sample[i]
    if(treatment == 1){
      etai = tau + xi%*%beta + gamma_i
    } else{
      etai = xi%*%beta + gamma_i
    }
    if(response_mechanism == "logistic"){
      probi = exp(etai)/(1+exp(etai))
    } else{
      probi = pnorm(etai)
    }
  } else{
    if(all(adjmat_sample[i,] == 0)){
      exposure = 0
    } else{
      exposure = mean(treatments[adjmat_sample[i,] == 1])
    } else{
      exposure_indicator = exposure > exposure_threshold
      # print(exposure_indicator)
      if(treatment == 1){
        etai = tau + xi%*%beta + delta_fixed*exposure_indicator
      } else{
        etai = xi%*%beta + delta_fixed*exposure_indicator
      }
      probi = exp(etai)/(1+exp(etai))
    }
    
    
    
  }
  
  return(rbinom(1,1,probi))
  
}

##############################################################################
# simulate a naive A/B test. The naive A/B test uses a two-sample test for proportions 
# (without continuity correction).
# Inputs:
# ---- X_all: N times p matrix of all covariates
# ---- n: sample size
# ---- tau: true treatment effect (known in simulation)
# ---- beta: a vector of length p containing the covariate effects (known in simulation)
# ---- gamma_all: true cluster random effects (known in simulation)
# ---- delta_fixed: true exposure fixed effects (known in simulation)
# ---- adjmat: N times N adjacency matrix for all N individuals in the network
# ---- response_mechanism: one of "logistic", "probit", "threshold"
# ---- estimated_clusters: not needed for the naive A/B test, but used to find D-efficiency under certain models
############
# Returns:
# ---- data: a data frame containing the responses, covariates, and assigned treatments for the n sampled users
# ---- p.value: a p-value for testing a difference in the proportion of successes in the treatment and control groups.
naive_AB_test_sim = function(n,X_all,tau,beta, gamma_all, delta_fixed, adjmat, response_mechanism,
                             estimated_clusters, exposure_threshold = 0.5){
  
  Y = numeric(n)
  treatments = numeric(n)
  N = nrow(X_all)
  sampled_vertices = sample(1:N,n)
  gamma_sample = gamma_all[sampled_vertices]
  X_sample = X_all[sampled_vertices,]
  adjmat_sample = adjmat[sampled_vertices, sampled_vertices]
  cluster_labels_sample = estimated_clusters[sampled_vertices]
  for(i in 1:n){
    treatments[i] = rbinom(1,1,0.5) # in the naive test we just assign treatments with equal probability
    Y[i] = generate_next_response(treatments = treatments, X_sample = X_sample,
                                  tau = tau, beta = beta, gamma_sample = gamma_sample, response_mechanism = response_mechanism,
                                  delta_fixed = delta_fixed, adjmat_sample = adjmat_sample, i=i,
                                  exposure_threshold = exposure_threshold)
    
  }
  ABtest_df = data.frame(Y = Y, X = X_sample, treatment = treatments, cluster = as.factor(cluster_labels_sample))
  summary_table = ABtest_df %>% group_by(treatment) %>% summarize(num_success = sum(Y),
                                                                  n = n())
  summary_table_counts = as.matrix(summary_table)
  p.value = prop.test(x = summary_table_counts[,2], n = summary_table_counts[,3],
                      correct = FALSE)$p.value
  return(list(data = ABtest_df,p.value = p.value))
  
}
##############################################################################


cluster_stat <- function(Y, treatments, clusters) {
  s = 0
  K = length(unique(clusters)) 
  # weights =  # use weighted mean based on cluster variance?
  for (k in clusters) {
    idx <- clusters == k
    if (sum(treatments[idx] == 1) > 0 && sum(treatments[idx] == 0) > 0) {
      y1 <- mean(Y[idx & treatments == 1])
      y0 <- mean(Y[idx & treatments == 0])
      s <- s + (y1 - y0)
    }
  }
  return(s / K)
}


cluster_randomization_test <- function(Y, treatments, clusters, probs, B,
                                       n.cores){
  S_perm = numeric(B)
  S_obs = cluster_stat(Y=Y, treatments=treatments, clusters=clusters)
  myCluster = makeCluster(n.cores)
  doParallel::registerDoParallel(myCluster)
  S_perm <- foreach(b = 1:B, .export = c("cluster_stat"), .combine = c) %dopar% {
    Tb = rbinom(length(treatments), size = 1, prob = probs)
    tmp_out = cluster_stat(Y=Y, treatments=Tb, clusters=clusters)
    tmp_out
  }
  p.value = (1 + sum(abs(S_perm) >= abs(S_obs)))/(B+1)
  stopCluster(myCluster)
  return(p.value)
}

##############################################################################
# This function simulates an A/B test conducted using the proposed methods.
# Inputs:
# ---- X_all: N times p matrix of all covariates
# ---- estimated_clusters: a vector of length N containing the estimated cluster assignments
# ---- n1: Phase I sample size
# ---- n2: Phase II sample size
# ---- tau: true treatment effect (known in simulation)
# ---- beta: a vector of length p containing the covariate effects (known in simulation)
# ---- gamma_all: true cluster random effects (known in simulation)
# ---- delta_fixed: true exposure fixed effects (known in simulation)
# ---- adjmat: N times N adjacency matrix for all N individuals in the network
# ---- response_mechanism: one of "logistic", "probit", "threshold"
# ---- B: number of resamples used for the randomization test (default is 1000)
# ---- n.cores: number of cores for parallel processing (default is 10)
############
# Returns:
# ---- data: a data frame containing the responses, covariates, and assigned treatments for the n sampled users
# ---- p.value: a p-value for testing a difference in the proportion of successes in the treatment and control groups.
# A randomization test is used to find p.value. 
two_phase_ABtest_sim_randomization = function(n1,n2,estimated_clusters,X_all,tau,beta, gamma_all,
                                              delta_fixed, adjmat, response_mechanism, B = 1000,
                                              n.cores = 10, exposure_threshold = 0.5){
  
  n = n1 + n2
  Y = numeric(n)
  treatments = numeric(n)
  N = nrow(X_all)
  sampled_vertices = sample(1:N,n)
  gamma_sample = gamma_all[sampled_vertices]
  X_sample = X_all[sampled_vertices,]
  cluster_labels_sample = estimated_clusters[sampled_vertices]
  adjmat_sample = adjmat[sampled_vertices, sampled_vertices]
  assignment_probs = numeric(n)
  
  # Phase I
  
  # For users 1 to n1, use Phase I treatment assignment probabilities
  # Assign treatment to first user with probability 0.5
  treatments[1] = rbinom(1,1,prob = 0.5)
  Y[1] = generate_next_response(treatments = treatments, X_sample = X_sample,
                                tau = tau, beta = beta, gamma_sample = gamma_sample, response_mechanism = response_mechanism,
                                delta_fixed = delta_fixed, adjmat_sample = adjmat_sample, i=1,
                                exposure_threshold = exposure_threshold)
  
  for(i in 2:n1){
    
    ti1 = c(treatments[1:(i-1)],1)
    ti0 = c(treatments[1:(i-1)],0)
    Xi = X_sample[1:i,]
    Ci1 = sqrt(sum((t(Xi)%*%ti1)^2))
    Ci0 = sqrt(sum((t(Xi)%*%ti0)^2))
    # assign_prob_i = min(exp(-(Ci1 - Ci0)),1)
    assign_prob_i = 0.5
    assignment_probs[i] = assign_prob_i
    # print(paste("Phase I treatment assignment probability:" ,assign_prob_i, sep = ""))
    treatments[i] = rbinom(1,1,prob = assign_prob_i)
    Y[i] = generate_next_response(treatments = treatments, X_sample = X_sample,
                                  tau = tau, beta = beta, gamma_sample = gamma_sample, response_mechanism = response_mechanism,
                                  delta_fixed = delta_fixed, adjmat_sample = adjmat_sample, i=i,
                                  exposure_threshold = exposure_threshold)
    
  }
  
  model_formula = paste("Y ~ -1 + treatment + ", paste("X.",1:(p+1),sep = "",collapse = "+"),
                        "+ (1 | cluster)",
                        sep = "", collapse = "")
  
  # For users n1+1 to n, use Phase II response-adaptive covariate-adjusted treatment assignment probabilities
  
  data_phaseI = data.frame(Y = Y[1:n1], X = X_sample[1:n1,], treatment = treatments[1:n1],
                           cluster = as.factor(cluster_labels_sample[1:n1]))
  
  phaseImodel = glmer(model_formula, data = data_phaseI,
                      family = "binomial")
  beta_hat_I = fixef(phaseImodel)
  gamma_hats_sample = ranef(phaseImodel)$cluster[phaseImodel@frame$cluster, 1]
  gamma_hats = phaseImodel@u
  
  for(i in (n1+1):n){
    
    temp = sqrt(i-n1)
    # temp = i-n1
    ti1 = c(treatments[1:(i-1)],1)
    ti0 = c(treatments[1:(i-1)],0)
    Xi = X_sample[1:i,]
    Zi1 = cbind(ti1, Xi)
    Zi0 = cbind(ti0, Xi)
    gamma_hats_sample = c(gamma_hats_sample, gamma_hats[cluster_labels_sample[i]])
    etai1 = Zi1%*%beta_hat_I + gamma_hats_sample
    mu1 = 1/(1+exp(-etai1))
    W1 = diag(as.vector(mu1*(1-mu1)))
    D1 = det( t(Zi1)%*%W1%*%Zi1 )
    etai0 = Zi0%*%beta_hat_I + gamma_hats_sample
    mu0 = 1/(1+exp(-etai0))
    W0 = diag(as.vector(mu0*(1-mu0)))
    D0 = det( t(Zi0)%*%W0%*%Zi0 )
    assign_prob_i = max(0.05,min( exp(-temp*(D0 - D1)),1-0.05))
    # assign_prob_i = 0.5
    assignment_probs[i] = assign_prob_i
    # print(paste("Phase II treatment assignment probability:" ,assign_prob_i, sep = ""))
    treatments[i] = rbinom(1,1,prob = assign_prob_i)
    Y[i] = generate_next_response(treatments = treatments, X_sample = X_sample,
                                  tau = tau, beta = beta, gamma_sample = gamma_sample, response_mechanism = response_mechanism,
                                  delta_fixed = delta_fixed, adjmat_sample = adjmat_sample, i=i,
                                  exposure_threshold = exposure_threshold)
    
    
  }
  
  # return the overall dataframe and p value
  df_all = data.frame(Y = Y, X = X_sample, treatment = treatments, cluster = as.factor(cluster_labels_sample),
                      probs = assignment_probs)
  
  model_formula_null = paste("Y ~ -1 + ", paste("X.",1:(p+1),sep = "",collapse = "+"),
                             "+ (1 | cluster)",
                             sep = "", collapse = "")
  null_model = glmer(model_formula_null, data = df_all, family = "binomial") # fit model without treatment
  # Y_residuals = Y - predict(null_model, df_all, type = "response") # Y - est P(Y = 1)
  Y_residuals = residuals(null_model, type = "pearson") # can also try type = "deviance"
  randomization.p.value = cluster_randomization_test(Y=Y_residuals, treatments = treatments,
                                                     clusters = cluster_labels_sample, 
                                                     probs = assignment_probs,
                                                     B = B, n.cores = n.cores)
  final_model = glmer(model_formula, data = df_all, family = "binomial")
  # print(summary(final_model))
  coef_summary = coef(summary(final_model))
  wald.p.value = coef_summary[1,4]
  return(list(data = df_all, randomization.p.value = randomization.p.value,
              wald.p.value = wald.p.value))
  
}
